P – Robot controlled with turtlesim key commands, including left and right.
